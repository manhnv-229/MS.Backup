﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MS.ApplicationCore.Utilities
{
    public static class CommonConst
    {
        public static string ServerFileUrl = null;
    }
}
