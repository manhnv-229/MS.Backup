﻿using MS.ApplicationCore.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MS.ApplicationCore.Interfaces.Repositories
{
    public interface IUnitRepository:IRepository<Unit>
    {
    }
}
