﻿using MS.ApplicationCore.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MS.ApplicationCore.Interfaces
{
    public interface IPictureService:IBaseService<Picture>
    {
    }
}
