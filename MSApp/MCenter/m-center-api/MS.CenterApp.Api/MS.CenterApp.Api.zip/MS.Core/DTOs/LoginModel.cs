﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MS.Core.Entities
{
    public class LoginModel
    {
        public string? Username { get; set; }

        public string? Password { get; set; }
    }
}
