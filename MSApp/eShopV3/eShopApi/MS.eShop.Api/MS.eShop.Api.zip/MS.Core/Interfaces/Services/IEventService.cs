﻿using MS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MS.Core.Interfaces
{
    public interface IEventService:IBaseService<Event>
    {
    }
}
