﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MS.Core.Utilities
{
    public static class CommonConst
    {
        public static string ServerFileUrl = null;
    }
}
